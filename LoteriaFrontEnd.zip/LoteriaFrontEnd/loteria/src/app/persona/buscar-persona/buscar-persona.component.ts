import { Component, OnInit } from '@angular/core';
import { PersonaService } from '../shared/persona.service';



@Component({
  selector: 'app-buscar-persona',
  templateUrl: './buscar-persona.component.html',
  styleUrls: ['./buscar-persona.component.css']
})
export class BuscarPersonaComponent implements OnInit {
  columnDef: any;
  rowData: any;

  constructor(private service: PersonaService) { 
  }

  ngOnInit() {
    this.columnDef = [
      { headerName: 'idtblPersona', field: 'idtblPersona', width: 100 },
      { headerName: 'tipoDocumento', field: 'tipoDocumento', width: 100 },
      { headerName: 'nroDocumento', field: 'nroDocumento', width: 100 },
      { headerName: 'nombres', field: 'nombres', width: 100 },
      { headerName: 'apellidos', field: 'apellidos', width: 100 },
      { headerName: 'fechaNacimiento', field: 'fechaNacimiento', width: 100 }
      
    ];
  }
   

    buscar(): void {
      this.rowData = [];
      this.service.obtenerListaPersona().subscribe(result => {
       this.rowData = result;
      
      }, error => {
         console.log(error);
      });
  
    }
}
