import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import * as ns from './personanamespace';



@Injectable({
  providedIn: 'root'
})
export class PersonaService {

    constructor(private http: HttpClient) { }

    obtenerListaPersona(): Observable<ns.Persnnamespace.PersonaEntity> {
        return this.http.get<ns.Persnnamespace.PersonaEntity>('http://localhost:8081/loteria/api/persona/obternerlista');
    }

    guardar(params: ns.Persnnamespace.PersonaEntity): Observable<string> {
        return this.http.post<string>('http://localhost:8081/loteria/api/persona/guardar', params);
    }

    actualizar(params: ns.Persnnamespace.PersonaEntity): Observable<string> {
        return this.http.post<string>('http://localhost:8081/loteria/api/persona/actualizar', params);
    }

    eliminar(params: ns.Persnnamespace.PersonaEntity): Observable<string> {
        return this.http.post<string>('http://localhost:8081/loteria/api/persona/eliminar', params);
    }

}