export namespace Persnnamespace {


    export interface PersonaEntity{
        idtblPersona: number; 
        tipoDocumento: string;
        nroDocumento: number;
        nombres: string;
        apellidos: string;
        fechaNacimiento: Date;
    }

    export interface PremioEntity{
        idtblPremio: number;
        descripcion: string;
        cantidad: number;

    }

}