import { Component, OnInit } from '@angular/core';
import * as ns from '../shared/personanamespace';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { PersonaService } from '../shared/persona.service'; 

@Component({
  selector: 'app-actualizar-persona',
  templateUrl: './actualizar-persona.component.html',
  styleUrls: ['./actualizar-persona.component.css']
})
export class ActualizarPersonaComponent implements OnInit {
  persona: ns.Persnnamespace.PersonaEntity;
  selcpersona: ns.Persnnamespace.PersonaEntity;
  myForm: FormGroup;
  lista: any;
  constructor(public fb: FormBuilder, private service: PersonaService) { 

    this.persona = {
      idtblPersona: null,
      tipoDocumento: null,
      nroDocumento: null,
      nombres: null,
      apellidos: null,
      fechaNacimiento: null
    };

    this.myForm = this.fb.group({
      tipoDocumento: ['', [Validators.required]],
      nroDocumento: ['', [Validators.required]],
      nombres: ['', [Validators.required]],
      apellidos: ['', [Validators.required]],
      fechaNacimiento: ['', [Validators.required]]
    });


  }

  ngOnInit() {
  
      
      this.service.obtenerListaPersona().subscribe(result => {
       this.lista = result;
       }, error => {
         console.log(error);
      });
  
  }


  seleccionarPersona(): void{
    
   console.log(this.selcpersona);
   this.myForm.setValue(this.selcpersona);

  }

  ingresar(): void{

    this.persona.tipoDocumento =  this.myForm.get('tipoDocumento').value;
    this.persona.nroDocumento =  this.myForm.get('nroDocumento').value;
    this.persona.nombres =  this.myForm.get('nombres').value;
    this.persona.apellidos =  this.myForm.get('apellidos').value;
    this.persona.fechaNacimiento =  this.myForm.get('fechaNacimiento').value;

 
    this.service.actualizar(this.persona).subscribe(result => {
      console.log(result);
    }, error => {
       console.log(error);
    });
  }

}

