import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IngresarPersonaComponent } from './ingresar-persona/ingresar-persona.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BuscarPersonaComponent } from './buscar-persona/buscar-persona.component';
import { MatDialogModule, MatFormFieldModule, MatIconModule, MatButtonModule, MatInputModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AgGridModule } from 'ag-grid-angular';
import { EliminarPersonaComponent } from './eliminar-persona/eliminar-persona.component';
import { ActualizarPersonaComponent } from './actualizar-persona/actualizar-persona.component';


@NgModule({
  declarations: [IngresarPersonaComponent, BuscarPersonaComponent, EliminarPersonaComponent, ActualizarPersonaComponent],
  imports: [
    CommonModule,
    NgbModule,
    MatFormFieldModule,
    FormsModule,
    MatButtonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatIconModule,
    MatInputModule,
    AgGridModule.withComponents([])

  ],
  exports: [
    IngresarPersonaComponent
  ]
 
})
export class PersonaModule { }
