import { Component, OnInit } from '@angular/core';
import * as ns from '../shared/personanamespace';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { PersonaService } from '../shared/persona.service';

@Component({
  selector: 'app-eliminar-persona',
  templateUrl: './eliminar-persona.component.html',
  styleUrls: ['./eliminar-persona.component.css']
})
export class EliminarPersonaComponent implements OnInit {
  selcpersona: ns.Persnnamespace.PersonaEntity;
  lista: any;
  constructor(private service: PersonaService) { 
    this.service.obtenerListaPersona().subscribe(result => {
      this.lista = result;
      }, error => {
        console.log(error);
     });
 

  }

  ngOnInit() {
  }

  seleccionarPersona(): void{
      this.service.eliminar(this.selcpersona).subscribe(result => {
      this.lista = result;
      }, error => {
        console.log(error);
     });
 
 
   }
}
