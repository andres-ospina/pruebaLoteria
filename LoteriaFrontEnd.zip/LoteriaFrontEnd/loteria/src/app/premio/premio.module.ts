import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AsignarPremioComponent } from './asignar-premio/asignar-premio.component';
import { AgGridModule } from 'ag-grid-angular';
import { MensajePopupComponent } from './mensaje-popup/mensaje-popup.component';
import { MatDialogModule, MatFormFieldModule, MatIconModule, MatButtonModule, MatTabsModule, MatInputModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
@NgModule({
  declarations: [AsignarPremioComponent, MensajePopupComponent],
  imports: [
    CommonModule,
    AgGridModule.withComponents([]),
    MatDialogModule,
    MatFormFieldModule, 
    MatIconModule,
    MatButtonModule,
    MatTabsModule,
    MatInputModule,
    BrowserAnimationsModule
  ],
  entryComponents: [MensajePopupComponent]
})
export class PremioModule { }
