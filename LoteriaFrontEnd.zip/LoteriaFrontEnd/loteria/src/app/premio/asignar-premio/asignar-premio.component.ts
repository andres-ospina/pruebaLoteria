import { Component, OnInit } from '@angular/core';
import { PremioService } from '../shared/premio.service';
import { MensajePopupComponent } from '../mensaje-popup/mensaje-popup.component';
import { MatDialog, MatDialogConfig } from '@angular/material';

@Component({
  selector: 'app-asignar-premio',
  templateUrl: './asignar-premio.component.html',
  styleUrls: ['./asignar-premio.component.css']
})
export class AsignarPremioComponent implements OnInit {

  columnDef: any;
  rowData: any;
  dialogConfig = new MatDialogConfig();
  mensaje: string;

  constructor(private service: PremioService, private dialog: MatDialog) { 
  }

  ngOnInit() {
    this.columnDef = [
      { headerName: 'personanombre', field: 'personanombre', width: 100 },
      { headerName: 'premioNombre', field: 'premioNombre', width: 100 }
     
    ];
  }
   

    buscar(): void {
      this.mensaje = '';
      this.rowData = [];
      this.service.obternerasigna().subscribe(result => {
       this.rowData = result;
      
      }, error => {
         console.log(error);
      });
  
    }

    asignarPremio(): void{
      this.mensaje = '';
      const dialogRef = this.dialog.open(MensajePopupComponent, this.dialogConfig);
      dialogRef.afterClosed().subscribe(respuestaDialog => {
       if (respuestaDialog === '1') {

      this.service.asignarpremio().subscribe(result => {
        this.mensaje = result.mensaje;
        }, error => {
          console.log(error);
       });

      }

    });

  }

}
