import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AsignarPremioComponent } from './asignar-premio.component';

describe('AsignarPremioComponent', () => {
  let component: AsignarPremioComponent;
  let fixture: ComponentFixture<AsignarPremioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AsignarPremioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AsignarPremioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
