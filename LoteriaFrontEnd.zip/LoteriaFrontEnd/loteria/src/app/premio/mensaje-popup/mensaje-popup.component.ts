import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';


@Component({
  selector: 'app-mensaje-popup',
  templateUrl: './mensaje-popup.component.html',
  styleUrls: ['./mensaje-popup.component.css']
})
export class MensajePopupComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<MensajePopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
  }


  si():void{
    this.dialogRef.close('1');
  }
}
