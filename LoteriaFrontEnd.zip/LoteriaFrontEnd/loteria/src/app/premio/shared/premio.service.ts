import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import * as ns from './premionamespace';



@Injectable({
  providedIn: 'root'
})
export class PremioService {

    constructor(private http: HttpClient) { }

    obternerasigna(): Observable<ns.Preminamespace.AsignarPremioDTO> {
        return this.http.get<ns.Preminamespace.AsignarPremioDTO>('http://localhost:8081/loteria/api/premio/obtenerasigna');
    }

    asignarpremio(): Observable<any> {
        return this.http.get<any>('http://localhost:8081/loteria/api/premio/asignarpremio');
    }
    
    
}