export namespace Preminamespace {

export interface AsignarPremioDTO{
    personanombre: string;
    premioNombre: string;
}

}