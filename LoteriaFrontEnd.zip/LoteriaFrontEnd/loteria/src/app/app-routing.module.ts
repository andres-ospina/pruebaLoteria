import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IngresarPersonaComponent } from '../app/persona/ingresar-persona/ingresar-persona.component';
import { BuscarPersonaComponent } from '../app/persona/buscar-persona/buscar-persona.component';
import { AsignarPremioComponent } from '../app/premio/asignar-premio/asignar-premio.component';
import { EliminarPersonaComponent } from '../app/persona/eliminar-persona/eliminar-persona.component';
import { ActualizarPersonaComponent } from '../app/persona/actualizar-persona/actualizar-persona.component';

const routes: Routes = [
  
  { path: 'persona/ingresar', component: IngresarPersonaComponent},
  { path: 'persona/buscar', component: BuscarPersonaComponent},
  { path: 'persona/eliminar', component: EliminarPersonaComponent},
  { path: 'persona/actualizar', component: ActualizarPersonaComponent},
  { path: 'premio/asignar', component: AsignarPremioComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { anchorScrolling: 'enabled', scrollPositionRestoration: 'enabled'})], 
  exports: [RouterModule]
})
export class AppRoutingModule { }
