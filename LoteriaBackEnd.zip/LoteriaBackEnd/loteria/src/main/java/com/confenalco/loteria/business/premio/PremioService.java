package com.confenalco.loteria.business.premio;


import java.util.List;

import com.confenalco.loteria.domain.AsignarPremioDTO;
import com.confenalco.loteria.domain.MensajeDTO;
import com.confenalco.loteria.entity.PremioEntity;

public interface PremioService {

  
  public List<PremioEntity> obtenerLista();
  
  public List<AsignarPremioDTO> obtenerAsignacion();
  
  public MensajeDTO asignarPremio();
  
  
}
