package com.confenalco.loteria.domain;

import java.io.Serializable;

public class AsignarPremioDTO implements Serializable{


  private static final long serialVersionUID = 1L;
  
  private String personanombre;
  private String premioNombre;
  
  public String getPersonanombre() {
    return personanombre;
  }
  public void setPersonanombre(String personanombre) {
    this.personanombre = personanombre;
  }
  public String getPremioNombre() {
    return premioNombre;
  }
  public void setPremioNombre(String premioNombre) {
    this.premioNombre = premioNombre;
  }
 
  
  
}
