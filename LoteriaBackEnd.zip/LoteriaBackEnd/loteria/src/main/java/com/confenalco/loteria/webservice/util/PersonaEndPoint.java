package com.confenalco.loteria.webservice.util;

import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.confenalco.loteria.business.persona.PersonaService;
import com.confenalco.loteria.entity.PersonaEntity;
import com.confenalco.loteria.webservice.jaxb.Persona;
import com.confenalco.loteria.webservice.jaxb.PersonaListaRequest;
import com.confenalco.loteria.webservice.jaxb.PersonaListaResponse;

@Endpoint
public class PersonaEndPoint {
  private static final String NAMESPACE_URI = "https://www.confenalco.com/xml/loteria";

  @Autowired
  private PersonaService service;

  @PayloadRoot(namespace = NAMESPACE_URI, localPart = "PersonaListaRequest")
  @ResponsePayload
  public PersonaListaResponse getPersona(@RequestPayload PersonaListaRequest request) throws DatatypeConfigurationException {
    PersonaListaResponse response = new PersonaListaResponse();
    obtenerPersona(response);
    return response;
  }

  private void obtenerPersona(PersonaListaResponse response) throws DatatypeConfigurationException {

    for (PersonaEntity personaEntity : service.obtenerListaPersona()) {

      Persona persona = new Persona();
      persona.setApellidos(personaEntity.getApellidos());
      GregorianCalendar cal = new GregorianCalendar();
      cal.setTime(personaEntity.getFechaNacimiento());
      XMLGregorianCalendar gc = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
      persona.setFechaNacimiento(gc);
      persona.setIdtblPersona(personaEntity.getIdtblPersona());
      persona.setNombres(personaEntity.getNombres());
      persona.setNroDocumento(personaEntity.getNroDocumento());
      response.getPersona().add(persona);

    }

  }
}
