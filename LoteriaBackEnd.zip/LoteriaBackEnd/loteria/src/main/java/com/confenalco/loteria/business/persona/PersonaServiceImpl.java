package com.confenalco.loteria.business.persona;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.confenalco.loteria.entity.PersonaEntity;
import com.confenalco.loteria.repository.persona.PersonaRepo;

/**
 * Se utiliza para implementar la logica de negocio de la persona
 * @author androsgu
 *
 */
@Service
public class PersonaServiceImpl implements PersonaService {

  @Autowired
  private PersonaRepo personaRepo;
  
  
  @Override
  public List<PersonaEntity> obtenerListaPersona() {
    return personaRepo.findAll();
  }

  @Override
  public String guardarPersona(PersonaEntity personaEntity) {
    
    try {
    personaRepo.save(personaEntity);
    return "Se creo la persona";
    } catch (Exception e) {
      return "No se creo la persona";
    }
    
  }

  @Override
  public String eliminarPersona(PersonaEntity personaEntity) {
   
    try {
      personaRepo.delete(personaEntity);
      return "Se elimino la persona";
      } catch (Exception e) {
        return "No se elimino la persona";
      }
   
  }

  @Override
  public String actualizarPersona(PersonaEntity personaEntity) {
    try {
      personaRepo.save(personaEntity);
      return "Se actualizo la persona";
      } catch (Exception e) {
        return "No se actualizo la persona";
      }
  }

}
