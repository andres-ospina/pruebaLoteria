package com.confenalco.loteria.dao.personapremio;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.confenalco.loteria.domain.AsignarPremioDTO;

/**
 * Se utiliza para realizar las consultas a la asignacion de premios
 * @author androsgu
 *
 */

@Repository
public class PersonaPremioDAO {


  /**
   * Template
   */
  private JdbcTemplate jdbcTemplate;

  /**
   * Template
   * 
   * @param dataSource
   */
  @Autowired
  public void setDataSource(DataSource dataSource) {
    this.jdbcTemplate = new JdbcTemplate(dataSource);
  }

  
  public List<AsignarPremioDTO> obtenerAsignacion() {
    StringBuilder sql = new StringBuilder();
    sql.append(" select ").append("\r\n");
    sql.append(" per.nombres, ").append("\r\n");
    sql.append(" pre.descripcion ").append("\r\n");
    sql.append(" from tbl_persona per, ").append("\r\n");
    sql.append(" tbl_persona_premio pp, ").append("\r\n");
    sql.append(" tbl_premio pre ").append("\r\n");
    sql.append(" where ").append("\r\n");
    sql.append(" per.idtbl_persona = pp.id_persona ").append("\r\n");
    sql.append(" and pp.id_premio = pre.idtbl_premio ").append("\r\n");

    return (this.jdbcTemplate).query(sql.toString(), new RowMapper<AsignarPremioDTO>() {
      public AsignarPremioDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        AsignarPremioDTO mapper = new AsignarPremioDTO();
        mapper.setPersonanombre(rs.getString(1));
        mapper.setPremioNombre(rs.getString(2));
        return mapper;
        
        
      }
    });

  }
}
