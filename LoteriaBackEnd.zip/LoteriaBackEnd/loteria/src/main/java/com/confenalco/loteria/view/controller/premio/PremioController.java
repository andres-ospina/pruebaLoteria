package com.confenalco.loteria.view.controller.premio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.confenalco.loteria.business.premio.PremioService;
import com.confenalco.loteria.domain.AsignarPremioDTO;
import com.confenalco.loteria.domain.MensajeDTO;
import com.confenalco.loteria.entity.PremioEntity;


@RestController
@RequestMapping(path = "/api/premio")
public class PremioController {
  
  @Autowired
  private PremioService service;

  @CrossOrigin
  @GetMapping(value = "/obternerlista", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public ResponseEntity<List<PremioEntity>> obtenerListaPremio() {
     return new ResponseEntity<>(service.obtenerLista(), HttpStatus.OK);
  }
  
  @CrossOrigin
  @GetMapping(value = "/asignarpremio", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public ResponseEntity<MensajeDTO> asignarPremio() {
     return new ResponseEntity<>(service.asignarPremio(), HttpStatus.OK);
  }
  
  @CrossOrigin
  @GetMapping(value = "/obtenerasigna", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public ResponseEntity<List<AsignarPremioDTO>> obtenerAsignacion(){
    return new ResponseEntity<>(service.obtenerAsignacion(), HttpStatus.OK);
    
  }
  
}
