package com.confenalco.loteria.business.persona;

import java.util.List;

import com.confenalco.loteria.entity.PersonaEntity;

/**
 * Se utiliza para matricular las firmas de las reglas de negocio de la persona
 * @author androsgu
 *
 */
public interface PersonaService {

  
  public List<PersonaEntity> obtenerListaPersona();
  
  public String guardarPersona(PersonaEntity personaEntity);
  
  public String eliminarPersona(PersonaEntity personaEntity);
  
  public String actualizarPersona(PersonaEntity personaEntity);
  
}
