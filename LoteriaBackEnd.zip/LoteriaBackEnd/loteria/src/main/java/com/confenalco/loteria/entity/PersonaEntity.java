package com.confenalco.loteria.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * Se utiliza para estructurar la tabla de persona
 * @author androsgu
 *
 */
@Entity
@Table(name = "tbl_persona")
public class PersonaEntity implements Serializable{

 
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  @Column(name="idtbl_persona")
  private Integer idtblPersona; 
  
  @Column(name="tipo_documento")
  private String tipoDocumento;
  
  @Column(name="nro_documento")
  private Integer nroDocumento;
  
  @Column(name="nombres")
  private String nombres;
  
  @Column(name="apellidos")
  private String apellidos;
  
  @Column(name="fecha_nacimiento")
  private Date fechaNacimiento;

  public Integer getIdtblPersona() {
    return idtblPersona;
  }

  public void setIdtblPersona(Integer idtblPersona) {
    this.idtblPersona = idtblPersona;
  }

  public String getTipoDocumento() {
    return tipoDocumento;
  }

  public void setTipoDocumento(String tipoDocumento) {
    this.tipoDocumento = tipoDocumento;
  }

  public Integer getNroDocumento() {
    return nroDocumento;
  }

  public void setNroDocumento(Integer nroDocumento) {
    this.nroDocumento = nroDocumento;
  }

  public String getNombres() {
    return nombres;
  }

  public void setNombres(String nombres) {
    this.nombres = nombres;
  }

  public String getApellidos() {
    return apellidos;
  }

  public void setApellidos(String apellidos) {
    this.apellidos = apellidos;
  }

  public Date getFechaNacimiento() {
    return fechaNacimiento;
  }

  public void setFechaNacimiento(Date fechaNacimiento) {
    this.fechaNacimiento = fechaNacimiento;
  }
  
  
  
  
}
