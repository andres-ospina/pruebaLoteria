package com.confenalco.loteria.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * Se utiliza para estructurar la tabla que relaciona la persona con el premio
 * @author androsgu
 *
 */
@Entity
@Table(name = "tbl_persona_premio")
public class PersonaPremioEntity implements Serializable{


  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  @Column(name = "idtbl_persona_premio")
  private Integer idtblPersonaPremio;

  @Column(name = "id_persona")
  private Integer idPersona;

  @Column(name = "id_premio")
  private Integer idPremio;

  public Integer getIdtblPersonaPremio() {
    return idtblPersonaPremio;
  }

  public void setIdtblPersonaPremio(Integer idtblPersonaPremio) {
    this.idtblPersonaPremio = idtblPersonaPremio;
  }

  public Integer getIdPersona() {
    return idPersona;
  }

  public void setIdPersona(Integer idPersona) {
    this.idPersona = idPersona;
  }

  public Integer getIdPremio() {
    return idPremio;
  }

  public void setIdPremio(Integer idPremio) {
    this.idPremio = idPremio;
  }
  
  
}
