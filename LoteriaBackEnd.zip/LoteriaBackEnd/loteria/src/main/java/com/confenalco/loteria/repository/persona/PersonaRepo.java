package com.confenalco.loteria.repository.persona;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.confenalco.loteria.entity.PersonaEntity;


/**
 * Se utiliza para realizar las consultas de la tabla persona
 * @author androsgu
 *
 */

@Repository
public interface PersonaRepo extends JpaRepository<PersonaEntity, Integer>{

}
