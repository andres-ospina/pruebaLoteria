package com.confenalco.loteria.repository.premio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.confenalco.loteria.entity.PremioEntity;


/**
 * Se utiliza para realizar las consultas de la tabla Premio
 * @author androsgu
 *
 */

@Repository
public interface PremioRepo extends JpaRepository<PremioEntity, Integer>{


}

