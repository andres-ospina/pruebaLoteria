package com.confenalco.loteria.business.premio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.confenalco.loteria.dao.personapremio.PersonaPremioDAO;
import com.confenalco.loteria.domain.AsignarPremioDTO;
import com.confenalco.loteria.domain.MensajeDTO;
import com.confenalco.loteria.entity.PersonaEntity;
import com.confenalco.loteria.entity.PersonaPremioEntity;
import com.confenalco.loteria.entity.PremioEntity;
import com.confenalco.loteria.repository.persona.PersonaRepo;
import com.confenalco.loteria.repository.personapremio.PersonaPremioRepo;
import com.confenalco.loteria.repository.premio.PremioRepo;

@Service
public class PremioServiceImpl implements PremioService{

  @Autowired
  private PremioRepo premioRepo;
  
  @Autowired
  private PersonaRepo personaRepo;
  
  @Autowired
  private PersonaPremioRepo personaPremioRepo;
  
  @Autowired
  private PersonaPremioDAO personaPremioDAO;
  
  @Override
  public List<PremioEntity> obtenerLista() {
    return premioRepo.findAll();
  }

  @Override
  public List<AsignarPremioDTO> obtenerAsignacion() {
   return personaPremioDAO.obtenerAsignacion();
  }

  @Override
  public MensajeDTO asignarPremio() {
    MensajeDTO men = new MensajeDTO();
    List<PersonaEntity> listPersona = personaRepo.findAll();
    List<PremioEntity> listPremios = premioRepo.findAll();
    
    int cantidP = listPersona.size();
    int cantidPre = obtnerCantidadP(listPremios);
    
    if(cantidP > cantidPre) {
      men.setMensaje("No se tiene suficiente cantidad de premios para las personas");
      return men;
    }
    
    asignarPP(listPersona);
    men.setMensaje("Se asignaron premios a las personas");
    return men;
 
    
  }

  private void asignarPP(List<PersonaEntity> listPersona) {
    for(PersonaEntity per : listPersona) {
      List<PremioEntity> listPremios = premioRepo.findAll();
       registrarPr(per,listPremios);
       }
    
  }

  private void registrarPr(PersonaEntity per,  List<PremioEntity> listPremios) {
   
   for(PremioEntity ppr : listPremios) {
     
     if(ppr.getCantidad()>0) {
       PersonaPremioEntity pp = new PersonaPremioEntity();
       pp.setIdPersona(per.getIdtblPersona());
       pp.setIdPremio(ppr.getIdtblPremio());
       personaPremioRepo.save(pp);
       int ca = ppr.getCantidad() - 1;
       ppr.setCantidad(ca);
       premioRepo.save(ppr);
       break;
     }
     
   }
  }

  private int obtnerCantidadP(List<PremioEntity> listPremios) {
    
    int canti= 0;
    for(PremioEntity pr : listPremios) {
      canti = canti + pr.getCantidad();
    }
    
    
    return canti;
  }

}
