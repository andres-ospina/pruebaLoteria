package com.confenalco.loteria.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_premio")
public class PremioEntity implements Serializable{

  
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  @Column(name="idtbl_premio")
  private Integer idtblPremio;
  
  @Column(name="descripcion")
  private String descripcion;
  
  @Column(name="cantidad")
  private Integer cantidad;

  public Integer getIdtblPremio() {
    return idtblPremio;
  }

  public void setIdtblPremio(Integer idtblPremio) {
    this.idtblPremio = idtblPremio;
  }

  public String getDescripcion() {
    return descripcion;
  }

  public void setDescripcion(String descripcion) {
    this.descripcion = descripcion;
  }

  public Integer getCantidad() {
    return cantidad;
  }

  public void setCantidad(Integer cantidad) {
    this.cantidad = cantidad;
  }
  
  
  
  
}
