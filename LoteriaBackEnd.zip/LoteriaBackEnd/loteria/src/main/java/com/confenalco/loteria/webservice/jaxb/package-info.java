//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantaci�n de la referencia de enlace (JAXB) XML v2.2.7 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perder�n si se vuelve a compilar el esquema de origen. 
// Generado el: 2019.08.04 a las 05:00:49 PM COT 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "https://www.confenalco.com/xml/loteria", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.confenalco.loteria.webservice.jaxb;
