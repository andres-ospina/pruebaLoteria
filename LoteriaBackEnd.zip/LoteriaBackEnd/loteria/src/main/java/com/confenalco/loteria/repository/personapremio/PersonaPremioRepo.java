package com.confenalco.loteria.repository.personapremio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.confenalco.loteria.entity.PersonaPremioEntity;

/**
 * Se utiliza para realizar las consultas de la tabla PersonaPremio
 * @author androsgu
 *
 */

@Repository
public interface PersonaPremioRepo  extends JpaRepository<PersonaPremioEntity, Integer>{


}
